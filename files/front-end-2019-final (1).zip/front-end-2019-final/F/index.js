function checkWin(f) {
    for (let i = 0; i < 3; i++) {
        if (f[i][0] == f[i][1] && f[i][1] == f[i][2] && f[i][0]) return f[i][0];
        if (f[0][i] == f[1][i] && f[1][i] == f[2][i] && f[0][i]) return f[0][i];
    }
    if (f[0][0] == f[1][1] && f[1][1] == f[2][2] && f[1][1]) return f[1][1];
    if (f[0][2] == f[1][1] && f[1][1] == f[2][0] && f[1][1]) return f[1][1];
}

function isValidCoord(n) {
    return n == 0 || n == 1 || n == 2;
}

module.exports = function (player1, player2) {
    const field = [[,,,],[,,,],[,,,]];
    const players = [player1, player2];
    let turn = 0;
    let retries = 0;
    function onMove(player, _turn, sign) {
        player.on('move', (move) => {
            if (turn % 2 !== _turn) return;
            const [j, i] = move;
            if (!isValidCoord(j) || !isValidCoord(i) || field[j][i]) {
                if (++retries === 3) {
                    players[turn % 2].end('lose');
                    players[(turn+1) % 2].end('win');
                    turn = -1;
                } else {
                    player.retry();
                }
                return;
            }
            retries = 0;
            turn++;
            field[j][i] = sign;
            checkResults(move);
        });
    }
    function checkResults(lastMove) {
        let winner = checkWin(field);
        if (winner) {
            turn = -1;
            player1.end(winner === 'x' ? 'win' : 'lose');
            player2.end(winner === 'o' ? 'win' : 'lose');
        } else if (turn === 9) {
            player1.end('tie');
            player2.end('tie');
        } else {
            players[turn % 2].nextTurn(lastMove);
        }
    }
    onMove(player1, 0, 'x');
    onMove(player2, 1, 'o');
    players[0].nextTurn(null);
    // Your code here.  
};