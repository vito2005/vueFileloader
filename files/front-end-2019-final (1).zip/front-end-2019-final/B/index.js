module.exports = function findServer(servers, check) {
    return (function search(lo, hi) {
        if (lo + 1 === hi) {
            if (lo === 0) return check(servers[0]).then(r => r ? servers[1] : servers[0]);
            return Promise.resolve(servers[hi]);
        }
        const mid = (lo + hi) >> 1;
        return check(servers[mid]).then(result => {
            return result ? search(mid, hi) : search(lo, mid);
        });
    }(0, servers.length));
};
