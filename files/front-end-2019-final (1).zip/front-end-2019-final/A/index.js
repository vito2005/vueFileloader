module.exports = function (diffs) {  
    const result = [];
    let x = 0, y = 0;
    for (const pair of diffs) {
    	const copy = pair.slice();
    	if (pair[0] && x++ % 2) copy[0] = -copy[0];
        if (pair[1] && y++ % 2) copy[1] = -copy[1];
        result.push(copy);
    }
    return x % 2 === 0
    	&& y % 2 === 0
        ? result
        : null;
};
